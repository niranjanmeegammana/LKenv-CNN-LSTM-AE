import os
from pathlib import Path
from datetime import datetime
from PIL import Image
import numpy as np
import pandas as pd
from collections import defaultdict

# === CONFIGURATION ===
root_dir = Path(r"E:\Lkenv\nmdb")
csv_dir = Path(r"E:\Lkenv")
output_dir = Path(r"E:\Lkenv\sat_npy2")
output_dir.mkdir(parents=True, exist_ok=True)
cropped_dir = Path(r"E:\Lkenv\cropped2")
cropped_dir.mkdir(parents=True, exist_ok=True)

# Crop region for Bay of Bengal + Sri Lanka (pixel coordinates)
CROP_BOX = (210, 90, 390, 270)  # (left, top, right, bottom)
RESIZE_SHAPE = (128, 128)

# Metadata storage
records = []
best_image_per_day = defaultdict(lambda: {"file": None, "timestamp_diff": float("inf")})

print("Scanning folders to find best image per day...")

# First pass: Select closest image to 12:00 PM for each day
for folder, subdirs, files in os.walk(root_dir):
    if 'imgx' in folder:
        for file in files:
            if file.endswith(".jpg"):
                try:
                    unix_timestamp = int(file.split('_')[0])
                    date_obj = datetime.utcfromtimestamp(unix_timestamp)
                    date_str = date_obj.strftime('%Y-%m-%d')

                    # Compute difference to 12:00 PM
                    target_time = datetime(date_obj.year, date_obj.month, date_obj.day, 12, 0)
                    diff = abs((date_obj - target_time).total_seconds())

                    # Update if closer to 12:00 PM
                    if diff < best_image_per_day[date_str]["timestamp_diff"]:
                        best_image_per_day[date_str] = {
                            "file": file,
                            "folder": folder,
                            "unix_timestamp": unix_timestamp,
                            "timestamp_diff": diff
                        }
                except Exception as e:
                    print(f"⛔ Skipping {file}: {e}")

print(f"Found {len(best_image_per_day)} images (one per day)")

# Second pass: Process selected images
for date_str, info in best_image_per_day.items():
    try:
        file = info["file"]
        folder = info["folder"]
        unix_timestamp = info["unix_timestamp"]
        img_path = Path(folder) / file

        img = Image.open(img_path)

        # Crop and resize
        cropped = img.crop(CROP_BOX)
        resized = cropped.resize(RESIZE_SHAPE)
        normalized = np.array(resized) / 255.0

        # Save .npy
        npy_filename = f"{date_str}.npy"
        np.save(output_dir / npy_filename, normalized)

        # Save resized cropped image as reference
        resized.save(cropped_dir / file)

        # Record metadata
        records.append({
            "date": date_str,
            "path": str(npy_filename)
        })

        print(f" Processed {file} → {npy_filename}")

    except Exception as e:
        print(f" Failed processing {file}: {e}")

# Save metadata CSV
df = pd.DataFrame(records)
csv_path = csv_dir / "satellite_image_metadata_2.csv"
df.to_csv(csv_path, index=False)

print(f"\n Processing complete. Metadata saved to: {csv_path}")
