from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import time

# Setup browser options
options = Options()
options.add_argument("--headless")
options.add_argument("--disable-blink-features=AutomationControlled")
driver = webdriver.Chrome(options=options)

# Load main page
driver.get("https://www.desinventar.net/DesInventar/results.jsp")

# Wait for iframe to load
WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.ID, "formQuery"))
)

# Try to find Search button and click
try:
    search_btn = driver.find_element(By.XPATH, '//input[@value="Search"]')
    search_btn.click()
    print("Clicked Search")
except Exception as e:
    print("Search button not found:", e)
    driver.quit()
    exit()

# Wait for iframe to appear
time.sleep(3)
driver.switch_to.frame("main1")

records = []

while True:
    print("Scraping page...")

    rows = driver.find_elements(By.CSS_SELECTOR, "table.tablas tr")[1:]
    for row in rows:
        cols = row.find_elements(By.TAG_NAME, "td")
        if len(cols) >= 6:
            date = cols[0].text.strip()
            event = cols[1].text.strip()
            district = cols[4].text.strip()
            division = cols[5].text.strip()
            records.append([date, district, division, event])

    # Try clicking "Next >"
    try:
        next_button = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((By.LINK_TEXT, "Next >"))
        )
        next_button.click()
        time.sleep(3)
    except Exception:
        print("No more pages or failed to find Next button.")
        break

# Save results
df = pd.DataFrame(records, columns=["date", "district", "division", "event"])
df.to_csv("desinventar_all_disasters.csv", index=False)
print(f"Saved {len(df)} rows.")

driver.quit()
