import pandas as pd
import shutil
from pathlib import Path

# Load the metadata file
csv_path = r"E:\Lkenv\final_satellite_image_path.csv"
df = pd.read_csv(csv_path)

# Destination folder
dest_dir = Path(r"E:\Lkenv\sat_npy1")
dest_dir.mkdir(parents=True, exist_ok=True)

# Copy each .npy file
copied = 0
for path_str in df['processed_path']:
    src_path = Path(path_str)
    if src_path.exists():
        dest_path = dest_dir / src_path.name
        shutil.copy2(src_path, dest_path)
        copied += 1
    else:
        print(f"❌ File not found: {src_path}")

print(f"✅ Done. {copied} files copied to {dest_dir}")
