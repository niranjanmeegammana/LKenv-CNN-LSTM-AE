import os
import numpy as np
import pandas as pd

# === Set local paths ===
metadata_path = r"E:\Lkenv\satellite_image_metadata_2.csv"
image_folder = r"E:\Lkenv\sat_npy2"
output_path = r"E:\Lkenv\satellite_images_metadata_3.csv"

# === Load metadata CSV ===
df = pd.read_csv(metadata_path, parse_dates=["date"])

# === Collect brightness statistics ===
records = []
i=0
for _, row in df.iterrows():
    i=i+1
    print (i,row) 
    date_str = row['date'].strftime("%Y-%m-%d")
    image_file = os.path.join(image_folder, row['path'])

    try:
        image_data = np.load(image_file)
        stats = {
            "date_str": date_str,
            "mean_brightness": np.mean(image_data),
            "std_brightness": np.std(image_data),
            "max_brightness": np.max(image_data),
            "min_brightness": np.min(image_data),
        }
        records.append(stats)
    except Exception as e:
        print(f"Failed to load {image_file}: {e}")

# === Save results to CSV ===
result_df = pd.DataFrame(records)
result_df.to_csv(output_path, index=False)
print(f"Saved to {output_path}")
