import os
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

from flask import Flask, render_template, request
import pandas as pd
import numpy as np
import joblib
from tensorflow.keras.models import load_model

app = Flask(__name__)

# === Load model and dataset ===
model = load_model("rebalanced_autoencoder.keras")
scaler = joblib.load("standard_scaler.pkl")
df_all = pd.read_csv("weather_with_satellite.csv", parse_dates=["date"])
df_all = df_all.sort_values(["city", "date"]).reset_index(drop=True)

# === Feature Engineering ===
df_all['temperature_2m_c'] = df_all['temperature_2m'] - 273.15
df_all['dewpoint_temperature_2m_c'] = df_all['dewpoint_temperature_2m'] - 273.15
T = df_all['temperature_2m_c']
Td = df_all['dewpoint_temperature_2m_c']
df_all['humidity'] = 100 * (
    np.exp((17.625 * Td) / (243.04 + Td)) / np.exp((17.625 * T) / (243.04 + T))
)
df_all['humidity'] = df_all['humidity'].clip(upper=100.0)
df_all['brightness_range'] = df_all['max_brightness'] - df_all['min_brightness']

# === Config ===
feature_cols = [
    'rainfall_mm', 'surface_pressure', 'temperature_2m',
    'u_component_of_wind_10m', 'v_component_of_wind_10m',
    'temperature_2m_c', 'dewpoint_temperature_2m_c', 'humidity',
    'mean_brightness', 'std_brightness', 'max_brightness',
    'min_brightness', 'brightness_range'
]

WINDOW_SIZE = 8
THRESHOLD = 3.55e+11

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        city = request.form["city"].lower()
        date_str = request.form["date"].replace('/', '-')
        try:
            date = pd.to_datetime(date_str)
            df_city = df_all[df_all["city"].str.lower() == city].copy()
            df_city = df_city.sort_values("date")

            df_window = df_city[(df_city['date'] <= date) &
                                (df_city['date'] >= date - pd.Timedelta(days=7))]

            if len(df_window) < WINDOW_SIZE:
                result = f"<span class='error'>❗ Not enough data for {city} before {date.date()}</span>"
            else:
                X = df_window[feature_cols].ffill().bfill()
                X_scaled = scaler.transform(X)
                X_input = X_scaled.reshape(1, WINDOW_SIZE, len(feature_cols))
                X_recon = model.predict(X_input, verbose=0)
                mse = np.mean((X_input - X_recon) ** 2)
                predicted = int(mse > THRESHOLD)

                prediction_html = (
                    '<span class="error">🚨 Anomaly / Disaster Risk</span>' if predicted
                    else '<span class="success">✅ Normal</span>'
                )

                result = (
                    f"<b>City:</b> {city}<br>"
                    f"<b>Date:</b> {date.date()}<br>"
                    f"<b>MSE:</b> {mse:.5e}<br>"
                    f"<b>Threshold:</b> {THRESHOLD:.5e}<br>"
                    f"<b>Prediction:</b> {prediction_html}"
                )

        except Exception as e:
            result = f"<span class='error'>Error: {str(e)}</span>"

    return render_template("index.html", result=result)

if __name__ == "__main__":
    port = 8000
    print(f"🚀 App is running at: http://127.0.0.1:{port} (or your IP if hosted remotely)")
    app.run(host="0.0.0.0", port=port, debug=True)
